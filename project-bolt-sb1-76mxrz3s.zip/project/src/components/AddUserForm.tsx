import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { AddUserFormData, User, UserFormMode } from '../types';

interface AddUserFormProps {
  mode: UserFormMode;
  onClose: () => void;
  onSubmit: (data: AddUserFormData) => void;
}

export function AddUserForm({ mode, onClose, onSubmit }: AddUserFormProps) {
  const [formData, setFormData] = useState<AddUserFormData>({
    username: '',
    email: '',
    password: '',
    role: mode.type === 'update' ? (mode.user?.role || 'developer') : (mode.role || 'developer'),
  });

  useEffect(() => {
    if (mode.type === 'update' && mode.user) {
      setFormData({
        username: mode.user.name,
        email: mode.user.email,
        password: '',
        role: mode.user.role,
      });
    }
  }, [mode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  const title = mode.type === 'update' ? 'Update User' : `Add ${mode.role?.replace('_', ' ')}`;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700"
        >
          <X size={20} />
        </button>
        <h2 className="text-2xl font-bold mb-4 capitalize">{title}</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <input
              type="text"
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <input
              type="email"
              required
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Password {mode.type === 'update' && '(Leave blank to keep current password)'}
            </label>
            <input
              type="password"
              required={mode.type === 'add'}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
          >
            {mode.type === 'update' ? 'Update User' : 'Add User'}
          </button>
        </form>
      </div>
    </div>
  );
}