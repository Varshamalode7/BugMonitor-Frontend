export interface User {
  id: string;
  name: string;
  email: string;
  role: 'project_manager' | 'developer' | 'tester';
}

export interface AddUserFormData {
  username: string;
  email: string;
  password: string;
  role: User['role'];
}

export interface UserFormMode {
  type: 'add' | 'update';
  user?: User;
  role?: User['role'];
}