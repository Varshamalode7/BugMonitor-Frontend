import React, { useState, useRef, useEffect } from 'react';
import { UserPlus, LogOut, ChevronDown } from 'lucide-react';
import { AddUserForm } from './components/AddUserForm';
import { UsersTable } from './components/UsersTable';
import { User as UserType, AddUserFormData, UserFormMode } from './types';

function App() {
  const [showAddUserDropdown, setShowAddUserDropdown] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [userFormMode, setUserFormMode] = useState<UserFormMode | null>(null);
  const [users, setUsers] = useState<UserType[]>([
    {
      id: '1',
      name: 'John Smith',
      email: 'john.smith@example.com',
      role: 'project_manager'
    },
    {
      id: '2',
      name: 'Sarah Johnson',
      email: 'sarah.j@example.com',
      role: 'developer'
    },
    {
      id: '3',
      name: 'Michael Brown',
      email: 'm.brown@example.com',
      role: 'tester'
    },
    {
      id: '4',
      name: 'Emily Davis',
      email: 'emily.d@example.com',
      role: 'developer'
    },
    {
      id: '5',
      name: 'David Wilson',
      email: 'd.wilson@example.com',
      role: 'project_manager'
    },
    {
      id: '6',
      name: 'Lisa Anderson',
      email: 'l.anderson@example.com',
      role: 'tester'
    }
  ]);
  
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfileDropdown(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleFormSubmit = (data: AddUserFormData) => {
    if (userFormMode?.type === 'update' && userFormMode.user) {
      // Update existing user
      setUsers(users.map(user => 
        user.id === userFormMode.user?.id
          ? {
              ...user,
              name: data.username,
              email: data.email,
              role: data.role
            }
          : user
      ));
    } else {
      // Add new user
      const newUser: UserType = {
        id: Math.random().toString(36).substr(2, 9),
        name: data.username,
        email: data.email,
        role: data.role,
      };
      setUsers([...users, newUser]);
    }
  };

  const handleDeleteUser = (id: string) => {
    setUsers(users.filter(user => user.id !== id));
  };

  const handleUpdateUser = (user: UserType) => {
    setUserFormMode({ type: 'update', user });
  };

  const handleLogout = () => {
    // Implement logout logic here
    console.log('Logging out...');
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Bug Tracking System</h1>
            
            <div className="flex items-center space-x-4">
              {/* Add User Button with Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowAddUserDropdown(!showAddUserDropdown)}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  <UserPlus size={20} />
                  <span>Add User</span>
                  <ChevronDown size={16} />
                </button>

                {showAddUserDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-10">
                    <div className="py-1">
                      {['project_manager', 'developer', 'tester'].map((role) => (
                        <button
                          key={role}
                          onClick={() => {
                            setUserFormMode({ type: 'add', role: role as UserType['role'] });
                            setShowAddUserDropdown(false);
                          }}
                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 capitalize"
                        >
                          {role.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Profile Section */}
              <div className="relative" ref={profileRef}>
                <button
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                  className="flex items-center space-x-2 focus:outline-none"
                >
                  <img
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                    alt="Admin profile"
                    className="h-8 w-8 rounded-full ring-2 ring-white"
                  />
                  <ChevronDown size={16} className="text-gray-500" />
                </button>

                {showProfileDropdown && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-20">
                    <div className="py-1">
                      <div className="px-4 py-2 border-b border-gray-200">
                        <p className="font-medium text-gray-700">Admin User</p>
                        <p className="text-sm text-gray-500">admin@example.com</p>
                      </div>
                      <div className="py-1">
                        <button
                          onClick={handleLogout}
                          className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        >
                          <LogOut size={16} className="mr-2" />
                          Logout
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">User Management</h2>
            <UsersTable
              users={users}
              onDelete={handleDeleteUser}
              onUpdate={handleUpdateUser}
            />
          </div>
        </div>
      </main>

      {/* User Form Modal */}
      {userFormMode && (
        <AddUserForm
          mode={userFormMode}
          onClose={() => setUserFormMode(null)}
          onSubmit={handleFormSubmit}
        />
      )}
    </div>
  );
}

export default App;