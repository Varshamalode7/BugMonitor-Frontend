import { Bug } from '../types/bug';
import { Calendar, Circle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface BugCardProps {
  bug: Bug;
  onClick: () => void;
  isSelected: boolean;
}

const priorityColors = {
  Critical: 'bg-red-100 text-red-800',
  High: 'bg-orange-100 text-orange-800',
  Medium: 'bg-yellow-100 text-yellow-800',
  Low: 'bg-green-100 text-green-800',
};

const statusColors = {
  Open: 'bg-blue-100 text-blue-700',
  'In Progress': 'bg-orange-100 text-orange-700',
  Completed: 'bg-green-100 text-green-700',
};

function getInitials(name: string) {
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase();
}

function getRandomColor(name: string) {
  const colors = [
    'bg-blue-100 text-blue-600',
    'bg-purple-100 text-purple-600',
    'bg-pink-100 text-pink-600',
    'bg-indigo-100 text-indigo-600',
  ];
  const index = name.length % colors.length;
  return colors[index];
}

export default function BugCard({ bug, onClick, isSelected }: BugCardProps) {
  const dueDate = new Date(bug.due);
  const relativeTime = formatDistanceToNow(dueDate, { addSuffix: true });

  return (
    <div
      onClick={onClick}
      className={`
        p-4 rounded-xl transition-all cursor-pointer
        transform hover:scale-[1.01] hover:shadow-md
        focus:outline-none focus:ring-2 focus:ring-blue-400
        ${
          isSelected
            ? 'bg-blue-50 border-2 border-blue-200'
            : 'bg-white border border-gray-200 hover:border-blue-200'
        }
      `}
      tabIndex={0}
      role="button"
    >
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <h3 className="text-sm font-medium text-gray-900">{bug.title}</h3>
          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${priorityColors[bug.priority]}`}>
            {bug.priority}
          </span>
        </div>
        
        <div className="flex items-center space-x-4 text-sm">
          <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[bug.status]}`}>
            {bug.status}
          </span>
          <div className="flex items-center text-gray-500">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{relativeTime}</span>
          </div>
        </div>

        {bug.assignedTo && (
          <div className="flex items-center space-x-2">
            <div className={`h-8 w-8 rounded-full ${getRandomColor(bug.assignedTo.name)} flex items-center justify-center`}>
              <span className="text-sm font-semibold">
                {getInitials(bug.assignedTo.name)}
              </span>
            </div>
            <span className="text-sm text-gray-600">{bug.assignedTo.name}</span>
          </div>
        )}
      </div>
    </div>
  );
}