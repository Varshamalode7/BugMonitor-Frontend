import { Bug } from '../types/bug';
import { Calendar, Flag, User } from 'lucide-react';

interface BugDetailCardProps {
  bug: Bug;
}

export default function BugDetailCard({ bug }: BugDetailCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 space-y-6">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">{bug.title}</h2>
          <span className={`
            px-3 py-1 rounded-full text-sm font-medium
            ${bug.priority === 'Critical' && 'bg-red-100 text-red-800'}
            ${bug.priority === 'High' && 'bg-orange-100 text-orange-800'}
            ${bug.priority === 'Medium' && 'bg-yellow-100 text-yellow-800'}
            ${bug.priority === 'Low' && 'bg-green-100 text-green-800'}
          `}>
            {bug.priority}
          </span>
        </div>
        <p className="text-gray-600">{bug.description}</p>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Category</p>
            <p className="font-medium">{bug.category}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Status</p>
            <p className="font-medium">{bug.status}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Due Date</p>
              <p className="font-medium">{new Date(bug.due).toLocaleDateString()}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <User className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-sm text-gray-500">Created By</p>
              <p className="font-medium">{bug.createdBy.name}</p>
            </div>
          </div>

          {bug.assignedTo && (
            <div className="flex items-center space-x-2">
              <Flag className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">Assigned To</p>
                <p className="font-medium">{bug.assignedTo.name}</p>
              </div>
            </div>
          )}

          {bug.resolvedDate && (
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">Resolved Date</p>
                <p className="font-medium">{new Date(bug.resolvedDate).toLocaleDateString()}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}