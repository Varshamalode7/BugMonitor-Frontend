import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

interface NewBugModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (bugData: any) => void;
}

export default function NewBugModal({ isOpen, onClose, onSubmit }: NewBugModalProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'UI',
    priority: 'Medium',
    due: '',
  });

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  const priorityColors = {
    Critical: 'bg-red-100 text-red-800',
    High: 'bg-orange-100 text-orange-800',
    Medium: 'bg-yellow-100 text-yellow-800',
    Low: 'bg-green-100 text-green-800',
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div 
        className="bg-white rounded-xl p-6 w-full max-w-lg transform transition-all"
        style={{ animation: 'modal-pop 0.3s ease-out' }}
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Report New Bug</h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              required
              id="title"
              placeholder=" "
              className="peer w-full rounded-lg border border-gray-300 px-3 pt-4 pb-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
            <label
              htmlFor="title"
              className="absolute left-3 top-2 text-xs font-medium text-gray-500 transition-all
                peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-xs"
            >
              Title
            </label>
          </div>

          <div className="relative">
            <textarea
              required
              id="description"
              rows={4}
              placeholder=" "
              className="peer w-full rounded-lg border border-gray-300 px-3 pt-4 pb-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
            <label
              htmlFor="description"
              className="absolute left-3 top-2 text-xs font-medium text-gray-500 transition-all
                peer-placeholder-shown:top-3 peer-placeholder-shown:text-base peer-focus:top-2 peer-focus:text-xs"
            >
              Description
            </label>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select
                className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              >
                <option>UI</option>
                <option>Backend</option>
                <option>Performance</option>
                <option>Security</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Priority
              </label>
              <select
                className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
              >
                {Object.entries(priorityColors).map(([priority, colorClass]) => (
                  <option key={priority} value={priority}>
                    {priority}
                  </option>
                ))}
              </select>
              <div className={`mt-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${priorityColors[formData.priority as keyof typeof priorityColors]}`}>
                {formData.priority}
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Due Date
            </label>
            <input
              type="date"
              required
              className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={formData.due}
              onChange={(e) => setFormData({ ...formData, due: e.target.value })}
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:text-gray-900 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Create Bug
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}