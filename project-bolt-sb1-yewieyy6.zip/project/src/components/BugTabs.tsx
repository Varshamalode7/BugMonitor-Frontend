import { TabType } from '../types/bug';

interface BugTabsProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  counts: Record<TabType, number>;
}

export default function BugTabs({ activeTab, onTabChange, counts }: BugTabsProps) {
  const tabs: TabType[] = ['Open', 'In Progress', 'Resolved', 'All'];

  return (
    <div className="border-b border-gray-200">
      <nav className="flex space-x-8" aria-label="Tabs">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => onTabChange(tab)}
            className={`
              py-4 px-1 inline-flex items-center border-b-2 font-medium
              focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 rounded-t-lg
              transition-all
              ${
                activeTab === tab
                  ? 'border-blue-600 text-blue-600 text-base font-semibold'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 text-sm'
              }
            `}
          >
            {tab}
            <span className={`ml-2 rounded-full px-2.5 py-0.5 text-xs font-medium
              ${activeTab === tab ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-900'}
            `}>
              {counts[tab]}
            </span>
          </button>
        ))}
      </nav>
    </div>
  );
}