import { Bug, Layout, LogOut, User } from 'lucide-react';
import { useState } from 'react';

export default function Sidebar() {
  const [active, setActive] = useState('bugs');
  
  const menuItems = [
    { id: 'bugs', label: 'Bugs', icon: Bug },
    { id: 'details', label: 'Project Details', icon: Layout },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'logout', label: 'Logout', icon: LogOut },
  ];

  return (
    <div className="fixed left-0 top-0 h-full w-64 bg-white shadow-lg p-6">
      <div className="space-y-6">
        <h1 className="text-xl font-semibold text-gray-800">Bug Tracking System</h1>
        <div className="pt-4">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
              <span className="text-blue-600 font-semibold">BT</span>
            </div>
            <div>
              <p className="text-sm font-semibold text-gray-800">Bob Thompson</p>
              <p className="text-xs text-gray-500">Tester</p>
            </div>
          </div>
        </div>
        <nav className="space-y-1 pt-6">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActive(item.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                  active === item.id
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}