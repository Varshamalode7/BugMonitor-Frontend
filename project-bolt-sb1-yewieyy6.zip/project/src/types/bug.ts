export interface User {
  userID?: number;
  name: string;
  email: string;
}

export interface Bug {
  bugId: number;
  title: string;
  category: string;
  description: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Progress' | 'Completed';
  due: string;
  resolvedDate: string | null;
  assignedTo: User | null;
  createdBy: User;
}

export type TabType = 'Open' | 'In Progress' | 'Resolved' | 'All';