import { useState } from 'react';
import { Plus, SortAsc, Filter } from 'lucide-react';
import Sidebar from './components/Sidebar';
import BugTabs from './components/BugTabs';
import BugCard from './components/BugCard';
import BugDetailCard from './components/BugDetailCard';
import NewBugModal from './components/NewBugModal';
import { Bug, TabType } from './types/bug';

// Dummy data
const DUMMY_BUGS: Bug[] = [
  {
    bugId: 1,
    title: "Navbar not responsive",
    category: "UI",
    description: "Navbar overlaps content on mobile view.",
    priority: "High",
    status: "Open",
    due: "2025-04-15",
    resolvedDate: null,
    assignedTo: null,
    createdBy: {
      userID: 2,
      name: "Bob",
      email: "bob@example.com"
    }
  },
  {
    bugId: 2,
    title: "Login API error",
    category: "Backend",
    description: "500 error on incorrect credentials.",
    priority: "Medium",
    status: "In Progress",
    due: "2025-04-20",
    resolvedDate: null,
    assignedTo: {
      name: "Alice",
      email: "alice@example.com"
    },
    createdBy: {
      userID: 2,
      name: "Bob",
      email: "bob@example.com"
    }
  },
  {
    bugId: 3,
    title: "Profile image not loading",
    category: "UI",
    description: "Default avatar not shown if no image is uploaded.",
    priority: "Low",
    status: "Completed",
    due: "2025-04-05",
    resolvedDate: "2025-04-08",
    assignedTo: {
      name: "Alice",
      email: "alice@example.com"
    },
    createdBy: {
      userID: 2,
      name: "Bob",
      email: "bob@example.com"
    }
  }
];

type SortOption = 'newest' | 'due-soon' | 'priority';
type FilterOption = 'all' | 'assigned' | 'unassigned';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('Open');
  const [selectedBug, setSelectedBug] = useState<Bug | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [filterBy, setFilterBy] = useState<FilterOption>('all');

  const filteredBugs = DUMMY_BUGS.filter(bug => {
    // First apply status filter
    const statusMatch = activeTab === 'All' ? true :
      activeTab === 'Resolved' ? bug.status === 'Completed' :
      activeTab === 'In Progress' ? bug.status === 'In Progress' :
      bug.status === 'Open';

    // Then apply assignment filter
    const assignmentMatch = filterBy === 'all' ? true :
      filterBy === 'assigned' ? bug.assignedTo !== null :
      bug.assignedTo === null;

    return statusMatch && assignmentMatch;
  }).sort((a, b) => {
    if (sortBy === 'due-soon') {
      return new Date(a.due).getTime() - new Date(b.due).getTime();
    }
    if (sortBy === 'priority') {
      const priorityOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    // Default to newest
    return new Date(b.due).getTime() - new Date(a.due).getTime();
  });

  const counts = {
    Open: DUMMY_BUGS.filter(bug => bug.status === 'Open').length,
    'In Progress': DUMMY_BUGS.filter(bug => bug.status === 'In Progress').length,
    Resolved: DUMMY_BUGS.filter(bug => bug.status === 'Completed').length,
    All: DUMMY_BUGS.length,
  };

  const handleNewBug = (bugData: any) => {
    console.log('New bug:', bugData);
    // Here you would typically make an API call to create the bug
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar />
      
      <main className="pl-64">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-semibold text-gray-900">Bug Reports</h1>
            <button
              onClick={() => setIsModalOpen(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="h-5 w-5 mr-2" />
              Report Bug
            </button>
          </div>

          <BugTabs
            activeTab={activeTab}
            onTabChange={setActiveTab}
            counts={counts}
          />

          <div className="flex items-center space-x-4 mt-6 mb-4">
            <div className="flex items-center space-x-2">
              <SortAsc className="h-4 w-4 text-gray-500" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="newest">Newest</option>
                <option value="due-soon">Due Soon</option>
                <option value="priority">Priority</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <select
                value={filterBy}
                onChange={(e) => setFilterBy(e.target.value as FilterOption)}
                className="text-sm border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="all">All Bugs</option>
                <option value="assigned">Assigned</option>
                <option value="unassigned">Unassigned</option>
              </select>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-12 gap-6">
            <div className="col-span-7 space-y-4">
              {filteredBugs.length > 0 ? (
                filteredBugs.map(bug => (
                  <BugCard
                    key={bug.bugId}
                    bug={bug}
                    onClick={() => setSelectedBug(bug)}
                    isSelected={selectedBug?.bugId === bug.bugId}
                  />
                ))
              ) : (
                <div className="text-center py-12 bg-white rounded-xl border border-gray-200">
                  <div className="text-6xl mb-4">🎉</div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No bugs here!</h3>
                  <p className="text-gray-500">Looks like everything is running smoothly.</p>
                </div>
              )}
            </div>
            
            <div className="col-span-5 sticky top-6">
              {selectedBug && <BugDetailCard bug={selectedBug} />}
            </div>
          </div>
        </div>
      </main>

      <NewBugModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleNewBug}
      />
    </div>
  );
}

export default App;